import React from 'react';
import { ExternalLink } from 'lucide-react';

const ProfileSection: React.FC = () => {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm mb-6 mx-4">
      <div className="flex items-start space-x-4 mb-6">
        <div className="w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0">
          <img
            src="./src/image/gambarku.jpg"
            alt="Kayyis Abdullah Al Hadi"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-gray-900 leading-tight mt-3">
            Kayyis Abdullah<br />Al Hadi
          </h1>
        </div>
      </div>
      
      <button className="w-full bg-gray-900 text-white py-3.5 px-4 rounded-2xl font-medium flex items-center justify-center space-x-2 hover:bg-gray-800 transition-colors duration-200">
        <ExternalLink className="w-4 h-4" />
        <span>Personal Website</span>
      </button>
    </div>
  );
};

export default ProfileSection;